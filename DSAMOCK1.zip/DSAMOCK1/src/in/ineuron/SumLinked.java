package in.ineuron;
import java.util.*;
public class SumLinked {

	public static void main(String[] args) {
		
		LinkedList<Integer> l1=new LinkedList<>(Arrays.asList(2,4,3));
		LinkedList<Integer> l2=new LinkedList<>(Arrays.asList(5,6,4));
		LinkedList<Integer> l3=new LinkedList<>();
		
		int n1=l1.size();
		int n2=l2.size();
		int carry=0;
		int n=(n1>n2)?n1:n2;
		for(int i=0;i<n;i++) {
			int sum=carry;
			if(i<n1) {
				sum+=l1.get(i);
			}
			if(i<n2) {
				sum+=l2.get(i);
			
			}
			carry=sum/10;
			sum=sum%10;
			l3.add(sum);
		}
		if(carry>0)
			l3.add(carry);
		System.out.println(Arrays.asList(l3));

	}

}
